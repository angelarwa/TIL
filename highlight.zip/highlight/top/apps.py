from django.apps import AppConfig


class TopConfig(AppConfig):
    name = 'top'

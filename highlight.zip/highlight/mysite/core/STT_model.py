#!/usr/bin/env python
# coding: utf-8


import time
import boto3
import urllib.request, json 
import uuid
import requests
import json
import re
import codecs
from time import gmtime, strftime
from moviepy.editor import *
from moviepy import editor
from moviepy.video.tools.subtitles import SubtitlesClip, TextClip
from time import gmtime, strftime
import numpy as np

import pickle
# from pydub import AudioSegment
import logging
from botocore.exceptions import ClientError
import matplotlib.pyplot as plt
# import cv2
import numpy as np
import pandas as pd


# AKIAS3UCLIDDI453Q4RX
# qrgaKoy5zfg7EM5QrP6yw6TOQWNT86TYre2GxDZ9

# from audioUtils import *


  


# TextClip.list('font')
font_setting = 'MDotum'


  


s3 = boto3.resource('s3')

AWS_ACCESS_KEY_ID = 'AKIAS3UCLIDDI453Q4RX'
AWS_SECRET_ACCESS_KEY = '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'
AWS_DEFAULT_REGION = 'ap-northeast-2'


  


def createTranscribeJob(job_name,  region, bucket, mediaFile ):

    # Set up the Transcribe client 
    transcribe = boto3.client('transcribe',
                    aws_access_key_id = AWS_ACCESS_KEY_ID,
                    aws_secret_access_key = AWS_SECRET_ACCESS_KEY,
                    region_name = AWS_DEFAULT_REGION)
    print( "Creating Job: " + "transcribe" + mediaFile + " for " + mediaUri )
    
    # Use the uuid functionality to generate a unique job name.  Otherwise, the Transcribe service will return an error
    response = transcribe.start_transcription_job( TranscriptionJobName=job_name, 
        LanguageCode = "ko-KR", 
        MediaFormat = "mp3", 
        Media = { "MediaFileUri" : mediaUri }, 
        )
    print(response)
    
    while True:
        status = transcribe.get_transcription_job(TranscriptionJobName=job_name)
        if status['TranscriptionJob']['TranscriptionJobStatus'] in ['COMPLETED', 'FAILED']:
            break
        print("Not ready yet...")
        time.sleep(5)
    print(status)
    
    return status



def create_bucket(bucket_name, region=None):
    """Create an S3 bucket in a specified region

    If a region is not specified, the bucket is created in the S3 default
    region (us-east-1).

    :param bucket_name: Bucket to create
    :param region: String region to create bucket in, e.g., 'us-west-2'
    :return: True if bucket created, else False
    """

    # Create bucket
    try:
        if region is None:
            s3_client = boto3.client('s3')
            s3_client.create_bucket(Bucket=bucket_name)
        else:
            s3_client = boto3.client('s3', region_name=region)
            location = {'LocationConstraint': region}
            s3_client.create_bucket(Bucket=bucket_name,
                                    CreateBucketConfiguration=location)
    except ClientError as e:
        logging.error(e)
        return False
    return True


bucket_name = 'jyseo'
region = 'ap-northeast-2'

# s3 버켓 생성
create_bucket(bucket_name, region=region)

# s3 객체 생성
s3 = boto3.client('s3')
response = s3.list_buckets()
for bucket in response['Buckets']:
    print(f'  {bucket["Name"]}')

# 파일 업로드
# with open('./video/lol3.mp4', 'rb') as f:
#     s3.upload_fileobj(f, bucket_name, 'lol3.mp4')


   


job_name = '0513-15'
LanguageCODE = 'ko-KR'
MediaFormat  = 'mp3'
mediaUri = "s3://jyseo/test_audio.mp3"
region = 'ap-northeast-2'
bucket = 'jyseo'
mediaFile = 'test_audio'

status = createTranscribeJob(job_name, region, bucket, mediaUri)


   


def getTranscript(transcriptURI):
    # Get the resulting Transcription Job and store the JSON response in transcript
    result = requests.get(transcriptURI)
    return result.json() #result.text


   


transcript = getTranscript(status['TranscriptionJob']['Transcript']['TranscriptFileUri'])
# transcript = getTranscript(str(status['TranscriptionJob']['Transcript']['TranscriptFileUri']))
print(transcript)


   


# {"start_time":"8.7","end_time":"9.13","alternatives":[{"confidence":"0.9757","content":"유기농"}],"type":"pronunciation"}, {...

for i in range(0,10000000):
    print(transcript['results']['items'][i]['alternatives'][0]['confidence']) #confidence
    print(transcript['results']['items'][i]['alternatives'][0]['content']) #content

    if transcript['results']['items'][i]['alternatives'][0]['confidence'] == '0.0': #confidence 0.0일때(문자 , 혹은 .)-> 앞 문자에 , . 붙이기
        print(transcript['results']['items'][i-1]['alternatives'][0]['content']+transcript['results']['items'][i]['alternatives'][0]['content'])
    else: 
        print(transcript['results']['items'][i]['start_time']) #start_time  
        print(transcript['results']['items'][i]['end_time']) #end_time
    #transcript.get('start_time') == None
    print('')

# http://json.parser.online.fr/
# type(transcript)


   





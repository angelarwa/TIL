from django.shortcuts import render, redirect
from django.views.generic import TemplateView, ListView, CreateView
from django.core.files.storage import FileSystemStorage
from django.urls import reverse_lazy

from .forms import BookForm
from .models import Book

from django.http import HttpResponse, JsonResponse
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt

# from mysite.core import STT_model as stt
# import cv2

# @csrf_exempt
# def output(request):
#     src_txt =request.FILES['srctxt']
#     src_name = src_txt._name
#     src_path = open(settings.BASE_DIR+'/static/'+src_name, 'wb')
#     for i in src_txt.chunks():
#         src_path.write(i)
#     src_path.close()

#     ref_txt = request.FILES['reftxt']
#     ref_name = ref_txt._name
#     ref_path = open(settings.BASE_DIR+'/static/'+src_name, 'wb')
#     for i in ref_txt.chunks():
#         ref_path.write(i)
#     ref_path.close()

#     result = gm.makeupout(src_txt, ref_txt)
#     cv2.imwrite(settings.BASE_DIR+'/static/result.txt', result)
#     return render(request, 'output.html', 'result.txt')


class Home(TemplateView):
    template_name = 'home.html'


def upload(request):
    context = {}
    if request.method == 'POST':
        uploaded_file = request.FILES['document']
        fs = FileSystemStorage()
        name = fs.save(uploaded_file.name, uploaded_file)
        context['url'] = fs.url(name)
    return render(request, 'upload.html', context)


def book_list(request):
    books = Book.objects.all()
    return render(request, 'video_detail.html', {
        'books': books
    })
# book_list.html

def upload_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = BookForm()
    return render(request, 'upload_book.html', {
        'form': form
    })


def delete_book(request, pk):
    if request.method == 'POST':
        book = Book.objects.get(pk=pk)
        book.delete()
    return redirect('book_list')


class BookListView(ListView):
    model = Book
    template_name = 'class_book_list.html'
    context_object_name = 'books'


class UploadBookView(CreateView):
    model = Book
    form_class = BookForm
    success_url = reverse_lazy('class_book_list')
    template_name = 'upload_book.html'

# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('www', '0093_auto_20160622_2338'),
    ]
"""
    operations = [
        migrations.AlterField(
            model_name='statistics',
            name='time_delta',
            field=models.IntegerField(null=True, blank=True),
        ),
    ]
"""
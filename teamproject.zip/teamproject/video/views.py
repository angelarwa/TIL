
# Create your views here.
from django.shortcuts import render, redirect
from django.urls import reverse
from .models import Video


def video_list(request):
    video_list = Video.objects.all()
    return render(request, 'video/video_list.html', {'video_list': video_list})


def video_new(request):
    if request.method == 'POST':
        title = request.POST['title']
        video_key = request.POST['video_key']
        Video.objects.create(title=title, video_key=video_key)
        return redirect(reverse('video:list'))
    elif request.method == 'GET':
        return render(request, 'video/video_new.html')    


def video_detail(request, video_id):
    video = Video.objects.get(id=video_id)   
    return render(request, 'video/video_detail.html', {'video': video})

# def upload_file():
#     if request.method == 'POST':
#         # 파일이없다
#         if 'file' not in request.files:
#             flash('No file part')
#             return redirect(request.url)
        
#         # 파일네임이없다 ( .filename )
#         if file.filename == '':
#             flash('No selected file')
#             return redirect(request.url)
        
#         # 파일 가져오기 ( request.files['네임'] )
#         file = request.files['file']
            
#         if file and allowed_file(file.filename):
#             filename = secure_filename(file.filename)
#             # 업로드 ( .save(경로) )
#             file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
#             return redirect(url_for('uploaded_file', filename=filename))